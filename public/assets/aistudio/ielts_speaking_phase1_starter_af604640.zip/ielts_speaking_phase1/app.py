"""Run: streamlit run app.py"""
import json
import os
import streamlit as st
from dotenv import load_dotenv

from src.storage import init_db, start_session, current_question, progress, transcript, DEFAULT_DB
from src.examiner_agent import run_agent
from src.trace import recent_logs
from src.bank import load_tracks

load_dotenv()
st.set_page_config(page_title='IELTS Speaking Agent – Phase 1', page_icon='💬', layout='centered')
init_db()
st.title('💬 IELTS Speaking Mock Test')
st.caption('Text-only prototype · 3 parts · follow-up questions · persisted sessions')

with st.sidebar:
    st.subheader('Settings')
    live = st.checkbox('Use a real LLM agent', value=False,
                       help='Requires OPENAI_API_KEY. Offline mode uses a scripted tool-calling model.')
    learner = st.text_input('Learner ID (not real identity)', value='demo_student')
    track = st.selectbox('Topic', options=list(load_tracks()))
    if st.button('Start new mock test', use_container_width=True):
        st.session_state['sid'] = start_session(learner_id=learner, track=track)
        st.rerun()
    resume = st.text_input('Resume by session ID', placeholder='Paste a previous session ID')
    if st.button('Load saved session', use_container_width=True):
        try:
            progress(resume.strip())
            st.session_state['sid'] = resume.strip()
            st.rerun()
        except ValueError as err:
            st.error(str(err))

if 'sid' not in st.session_state:
    st.info('Choose a topic and click **Start new mock test** in the sidebar.')
    st.stop()

sid = st.session_state['sid']
try:
    state = progress(sid)
    question = current_question(sid)
except ValueError as err:
    st.error(str(err))
    st.stop()

st.code(sid, language=None)
st.caption('Save this session ID if you want to reopen the session after restarting the app.')
st.progress(state['completed'] / state['total'], text=f"Completed {state['completed']}/{state['total']} questions")

if question is not None:
    st.subheader(f"Part {question['part']} · Question {question['number']}/{question['total']}")
    st.markdown(question['text'])
    if question['kind'] == 'cue':
        st.info('Part 2: type a longer response. Audio and the official timing are not implemented in Phase 1.')
    with st.form(key=f"answer_form_{sid}_{question['question_id']}"):
        answer = st.text_area('Your English answer', height=160, max_chars=5000,
                              placeholder='Write your answer in English...')
        send = st.form_submit_button('Submit and continue', type='primary')
    if send:
        try:
            if not answer.strip():
                st.warning('Please enter an answer.')
            else:
                with st.spinner('Agent is saving your answer and fetching the next question...'):
                    result = run_agent(sid, 'submit', question_id=question['question_id'],
                                       answer=answer, live_llm=live)
                if result['progress']['completed'] != state['completed'] + 1:
                    st.error('The agent did not save the answer. Try again or inspect logs.')
                else:
                    st.rerun()
        except Exception as err:
            st.error(f'Agent error: {err}')
else:
    st.success('Mock test complete! You can review your transcript below.')
    st.caption('Text-only practice: no speaking band, fluency or pronunciation score is claimed.')

with st.expander('📃 Transcript', expanded=question is None):
    rows = transcript(sid)
    if not rows:
        st.write('No saved answers yet.')
    for item in rows:
        st.markdown(f"**Examiner:** {item['question_text']}")
        st.markdown(f"**You:** {item['answer_text']}")
    st.download_button('Download transcript JSON',
                       data=json.dumps(rows, ensure_ascii=False, indent=2),
                       file_name=f'{sid}_transcript.json', mime='application/json')

with st.expander('🛠 Agent trace (recent steps)'):
    st.json(recent_logs(sid))

st.caption('Questions in this prototype are original learning examples, not official IELTS materials.')
